
The /experiments/50x100 directory contains four precomputed datasets of approval elections with 50 candidates and 100 voters.

These datasets originate from the paper:

How to Sample Approval Elections?
S. Szufa, P. Faliszewski, Ł. Janeczko, M. Lackner, A. Slinko, K. Sornat, N. Talmon
https://www.ijcai.org/proceedings/2022/0071.pdf

Moreover, there are two examples of usage of provided datasets:
example_01.py
example_02.py

