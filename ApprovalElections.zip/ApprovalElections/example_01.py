#
# PRINT ORIGINAL MAP
#

import mapof.elections as mapof


if __name__ == "__main__":

    experiment_id = '50x100/resampling'    # or disjoint or noise or truncated_urn or euclidean
    distance_id = 'l1-approvalwise'
    embedding_id = 'fr'

    experiment = mapof.prepare_offline_approval_experiment(experiment_id=experiment_id,
                                                           distance_id=distance_id,
                                                           embedding_id=embedding_id)
    experiment.print_map_2d(
        legend=False,
        textual=['empty', 'full', 'ID 0.5', 'IC 0.5'],
    )

