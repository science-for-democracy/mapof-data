#
# PRINT MAP COLORED BY YOUR OWN FEATURE
#

import mapof.elections as mapof


def my_feature(election) -> dict:
    """ implement your feature here """
    score = [0 for _ in range(election.num_candidates)]
    for vote in election.votes:
        for c in vote:
            score[c] += 1
    return {'value': max(score)}


if __name__ == "__main__":

    experiment_id = '100x1000/resampling'    # or disjoint or noise or euclidean
    distance_id = 'l1-approvalwise'
    embedding_id = 'fr'

    experiment = mapof.prepare_offline_approval_experiment(experiment_id=experiment_id,
                                                           distance_id=distance_id,
                                                           embedding_id=embedding_id,
                                                           fast_import=True)

    experiment.add_feature('my_feature', my_feature)
    experiment.compute_feature('my_feature')

    experiment.print_map_2d_colored_by_feature(
        cmap='Oranges',
        feature_id='my_feature',
        textual=['empty', 'full', 'ID 0.5', 'IC 0.5'],
        rounding=0
    )
