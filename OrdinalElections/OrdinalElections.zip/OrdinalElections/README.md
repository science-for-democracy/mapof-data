
The /experiments/10x50 directory contains a precomputed dataset of ordinal elections with 10 candidates and 50 voters.
The /experiments/10x100 directory contains a precomputed dataset of ordinal elections with 10 candidates and 100 voters.
The /experiments/20x100 directory contains a precomputed dataset of ordinal elections with 20 candidates and 100 voters.
The /experiments/100x100 directory contains a precomputed dataset of ordinal elections with 100 candidates and 100 voters.

Moreover, there are five examples of usage of provided datasets:
example_01.py
example_02.py
example_03.py
example_04.py
example_05.py

Last update on 29.11.2024
