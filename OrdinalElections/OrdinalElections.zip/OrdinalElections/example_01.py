#
# PRINT ORIGINAL MAP
#

import mapof.elections as mapof

if __name__ == "__main__":

    experiment_id = '10x50'
    distance_id = 'swap'
    embedding_id = 'fr'

    experiment = mapof.prepare_offline_ordinal_experiment(
        experiment_id=experiment_id,
        distance_id=distance_id,
        embedding_id=embedding_id,
    )

    experiment.print_map_2d(
        legend=False,
        textual=['ID', 'UN', 'ST', 'AN'],
        saveas='map',
        # urn_orangered=True,
    )
