#
# PRINT MAP COLORED BY YOUR OWN FEATURE
#

import mapof.elections as mapof


if __name__ == "__main__":
    experiment_id = '10x50'
    distance_id = 'swap'
    embedding_id = 'fr'

    experiment = mapof.prepare_offline_ordinal_experiment(experiment_id=experiment_id,
                                                          distance_id=distance_id,
                                                          embedding_id=embedding_id)
    feature_id = 'my_feature'
    experiment.print_map_2d_colored_by_feature(
        cmap='Oranges',
        feature_id=feature_id,
        rounding=0,
        mask='10x50-fr-swap-black',
        saveas='map'
    )
