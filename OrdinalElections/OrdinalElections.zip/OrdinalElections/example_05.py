#
# PRINT ORIGINAL MAP
#

import mapof.elections as mapof

if __name__ == "__main__":
    experiment_id = '100x100'
    distance_id = 'emd-positionwise'
    embedding_id = 'fr'

    experiment = mapof.prepare_offline_ordinal_experiment(
        experiment_id=experiment_id,
        distance_id=distance_id,
        embedding_id=embedding_id,
        fast_import=True    # skip importing votes
    )

    for election_id in experiment.families['Norm-Mallows'].election_ids:
        election = experiment.elections[election_id]
        election.printing_params['alpha'] = (election.params['normphi'] + 0.2) / 1.2

    for election_id in experiment.families['Urn'].election_ids:
        election = experiment.elections[election_id]
        election.printing_params['alpha'] = min(1, (election.params['alpha']/1.5 + 0.2) / 1.2)

    experiment.print_map_2d(
        legend=False,
        textual=['ID', 'UN', 'ST', 'AN'],
        title='My Title',
        title_size=24,
    )
